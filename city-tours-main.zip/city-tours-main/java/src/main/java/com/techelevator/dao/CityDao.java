package com.techelevator.dao;

import com.techelevator.model.City;

import java.util.List;

public interface CityDao {
    List<City> getCityList();
}
