package com.techelevator.Machine;

public class Chip extends Item{

    public Chip(String name, double price, int quantity){
        super(name, price, quantity, "Crunch, Crunch Yum!");
    }
    public Chip(){
        super();
    }


}
