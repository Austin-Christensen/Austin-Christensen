package com.techelevator.Machine;

public class Gum extends Item{

    public Gum(String name, double price, int quantity){
        super(name, price, quantity, "Chew Chew, Yum!");

    }


}
