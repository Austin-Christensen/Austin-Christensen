package com.techelevator.Machine;

public class Candy extends Item{
    public Candy(String name, double price, int quantity) {
        super(name, price, quantity, "Munch Munch, Yum!");
    }


}
