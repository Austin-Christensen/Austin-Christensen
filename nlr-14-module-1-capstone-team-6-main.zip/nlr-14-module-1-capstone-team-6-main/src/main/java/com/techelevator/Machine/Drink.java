package com.techelevator.Machine;

public class Drink extends Item{
    public Drink(String name, double price, int quantity) {
        super(name, price, quantity, "Glug Glug, Yum!");
    }


}
